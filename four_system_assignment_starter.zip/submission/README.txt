Evidence folders are intentionally templates. Run the official project commands and save actual outputs here. Do not present placeholder logs as passing test evidence.
