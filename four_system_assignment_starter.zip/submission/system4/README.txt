Required from your real run: test_output.txt, shift_output.txt, hot_state_size.txt, scratchpad_evidence.txt.
