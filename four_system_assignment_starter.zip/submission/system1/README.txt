Required from your real run: test_output.txt, summary.md, one trace with per-turn stop_reason.
