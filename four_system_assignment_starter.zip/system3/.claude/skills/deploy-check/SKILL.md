---
name: deploy-check
description: Read-only pre-deployment review with a structured verdict.
context: fork
allowed-tools:
  - Read
  - Grep
  - Glob
---
Inspect changed files and relevant tests. Do not edit or create files. Return PASS, WARN, or BLOCK; findings with file references; and missing checks.
