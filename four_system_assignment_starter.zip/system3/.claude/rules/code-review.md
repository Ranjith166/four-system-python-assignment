# Code review guidance
- Prefer focused changes.
- Check error handling and tests.
- Never expose secrets in logs or commits.
