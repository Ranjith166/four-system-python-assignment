Review the current diff for correctness, security, maintainability, and missing tests. Report file and line references. Do not modify files unless explicitly requested.
